const sponsorsData = [
  'chill',
  'paytm',
  'omg',
  'ip',
  'gm',
  'stepout',
  'coolberg',
  'bisleri',
  'matrix',
  'redbull',
  'toko',
  'euonusit',
]

export default sponsorsData
