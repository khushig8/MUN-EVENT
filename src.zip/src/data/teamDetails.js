const teams = [
  {
    teamName: 'Technical Team',
    members: [
      // {
      //   name: 'Amrit Srivastava',
      //   github: 'https://github.com/amritsrivastava',
      //   linkedIn: 'https://www.linkedin.com/in/amrit-srivastava',
      //   image: 'amrit.jpg',
      // },
      // {
      //   name: 'Aditya Agrawal',
      //   github: 'https://github.com/aditya81070',
      //   linkedIn: 'https://www.linkedin.com/in/aditya81070/',
      //   image: 'aditya.jpg',
      // },
      // {
      //   name: 'Darshit Gupta',
      //   github: 'https://github.com/dgupta777',
      //   linkedIn: 'https://www.linkedin.com/in/dgupta777/',
      //   image: 'darshit.jpg',
      // },
      // {
      //   name: 'Rajani Sharma',
      //   github: 'https://github.com/Rajani169',
      //   linkedIn: 'https://www.linkedin.com/in/rajani-sharma-4a93a6169',
      //   image: 'rajani.jpg',
      // },
      // {
      //   name: 'Keshav Kabra',
      //   github: 'https://github.com/ksvkabra',
      //   linkedIn: 'https://www.linkedin.com/in/ksvkabra/',
      //   image: 'keshav.jpg',
      // },
      {
        name: 'Chintan Grover',
        github: 'https://github.com/chianx',
        linkedIn: 'https://www.linkedin.com/in/chintan-grover-53a4481bb/',
        image: 'chintan.jpg',
      },
      {
        name: 'Khushi Garg',
        github: 'https://github.com/khushig8',
        linkedIn: 'https://www.linkedin.com/in/khushi-garg-0a8787187/',
        image: 'khushig.jpg',
      },
      {
        name: 'Rishit Mangal',
        github: 'https://github.com/',
        linkedIn: 'https://www.linkedin.com/in/rishit-mangal-a30672183/',
        image: 'rishit.jpg',
      },
    ],
  },
]

export default teams
