export const executives = [
  {
    committee: 'DISARMAMENT AND INTERNATIONAL SECURITY COMMITTEE',
    members: [
      {
        name: 'Abhishek Puri',
        designation: 'Chairperson',
        instagram: '#',
        twitter: '#',
        image: 'vardaanshekhawat.jpg',
      },
      {
        name: 'Shivam Gupta',
        designation: 'Vice-chairperson',
        instagram: '#',
        twitter: '#',
        image: 'akashkapoor.jpg',
      },
    ],
  },
  {
    committee: 'UNITED NATIONS SECURITY COUNCIL',
    members: [
      {
        name: 'Parth Raman',
        designation: 'President',
        instagram: '#',
        twitter: '#',
        image: 'raghavsodhi.jpg',
      },
      {
        name: 'Devansh Jaiswal',
        designation: 'Vice-President',
        instagram: '#',
        twitter: '#',
        image: 'shivanshchauhan.jpg',
      },
    ],
  },
  {
    committee: 'LOK SABHA',
    members: [
      {
        name: 'Naman Jain',
        designation: 'Speaker',
        instagram: '#',
        twitter: '#',
        image: 'vaibhavipathak.jpg',
      },
      {
        name: 'Aditya Dubey',
        designation: 'Deputy Speaker',
        instagram: '#',
        twitter: '#',
        image: 'harshilshah.jpg',
      },
    ],
  },
  {
    committee: 'INTERNATIONAL MONETARY FUND',
    members: [
      {
        name: 'Pratham Sharm',
        designation: 'Chairperson',
        instagram: '#',
        twitter: '#',
        image: 'mukundvatsa.jpg',
      },
      {
        name: 'Kabir wadhwa',
        designation: 'Vice-chairperson',
        instagram: '#',
        twitter: '#',
        image: 'prakharrathi.jpg',
      },
    ],
  },
]
